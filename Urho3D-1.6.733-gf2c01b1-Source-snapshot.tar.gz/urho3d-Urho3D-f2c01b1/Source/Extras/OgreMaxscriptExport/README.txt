
* Copy �Ogre� and �Startup� folders in 3dsmaxFolder\Scripts folder.
* Open 3ds max and open �MAXScript -> Run Script...� menu item.
* Select �initUrhoTools.ms� from �Startup� folder and press OK.

Add button
* Select �Customize -> Customize User Interface� menu item.
* Goto �Toolbar� tab.
* From �Category� list select �Urho tools� (Scroll down to see it).
* Drag �Urho Exporter� item to toolbar in 3dsmax to create button.
* Enjoy!


cin 
13.03.2013
vovapobeda@gmail.com